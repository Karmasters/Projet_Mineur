import csv
import random
from objet import *

################ Lancement du jeu ################

def verifier_nom(nom): # Au lancement du jeu on verifie si le nom est conforme.
    if nom.isalpha() and len(nom) <= 10:
        return True
    else:
        return False

################ On charge les ennemies / Objet / PNJ d'un coup ################

def charger_piece(): # On charge le dictionnaire en entier, pour afficher les descriptions au fur et a mesure
    pieces = {}
    with open("ressources/pieces.csv", newline="", encoding="utf-8") as f:
        lecteur = csv.DictReader(f)
        for ligne in lecteur:
            etage = int(ligne["etage"])
            piece = int(ligne["piece"])
            texte = str(ligne["texte"])
            pieces[etage, piece] = texte
    return pieces

def charger_objet():
    objets = []
    with open("ressources/objets.csv", newline="", encoding="utf-8") as f:
        lecteur = csv.DictReader(f)
        for ligne in lecteur:
            nom = str(ligne["nom"])
            type_objet = str(ligne["type_objet"])
            valeur_stat = int(ligne["valeur_stat"])
            valeur_or = int(ligne["valeur_or"])
            obj = Objet(nom, type_objet, valeur_stat, valeur_or)
            objets.append(obj)
    return objets

def charger_enemie():
    ennemis = []
    with open("ressources/ennemis.csv", newline="", encoding="utf-8") as f:
        lecteur = csv.DictReader(f)
        for ligne in lecteur:
            nom = str(ligne["nom"])
            pv = int(ligne["pv"])
            attaque = int(ligne["attaque"])
            defense = int(ligne["defense"])
            argent = int(ligne["argent"])
            or_butin = int(ligne["or_butin"])
            objet_butin = str(ligne["objet_butin"])
            ennemi_final = Ennemi(pv, argent, nom, attaque, defense, "Vivant", or_butin, objet_butin)
            ennemis.append(ennemi_final)
        return ennemis

def charger_pnj():
    pnjs = []
    with open("ressources/pnj.csv", newline="", encoding="utf-8") as f:
        lecteur = csv.DictReader(f)
        for ligne in lecteur:
            nom = str(ligne["nom"])
            pv = int(ligne["pv"])
            attaque = int(ligne["attaque"])
            defense = int(ligne["defense"])
            argent = int(ligne["argent"])
            or_transaction = int(ligne["or_transaction"])
            objet_transaction = str(ligne["objet_transaction"])
            type_pnj = str(ligne["type"])
            pnj_final = PNJ(pv, argent, nom, attaque, defense, "Vivant", or_transaction, objet_transaction, type_pnj)
            pnjs.append(pnj_final)
        return pnjs

def tirer_ennemi(etage, liste_ennemis): # On tire un enemie au sort en fonction de l'étage auquelle le joueur évolue.
    borne_max = min(60, etage * 3)
    index = random.randint(1, borne_max) - 1
    modele = liste_ennemis[index]
    return Ennemi(modele.pv, modele.argent, modele.nom, modele.attaque, modele.defense, "Vivant", modele.or_butin, modele.objet_butin)

def tirer_pnj(liste_pnj): # A chaque étage on tire un pnj au sort qui sera présent en pièce 3
    max = len(liste_pnj) - 1
    index = random.randint(0, max)
    modele = liste_pnj[index]
    return PNJ(modele.pv, modele.argent, modele.nom, modele.attaque, modele.defense, "Vivant", modele.or_transaction, modele.objet_transaction, modele.type_pnj)