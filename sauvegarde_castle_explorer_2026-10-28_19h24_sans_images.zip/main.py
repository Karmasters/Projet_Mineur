import sys
import os
import random
import unicodedata
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QPainter, QShortcut, QKeySequence
from PySide6.QtWidgets import *
from objet import *
from fonction import *

#On charge le bestiaire / les pieces / les ennemies
pieces = charger_piece()
objets_disponibles = charger_objet()
ennemis_disponibles = charger_enemie()
pnj_disponibles = charger_pnj()

ETAGE_FINAL = 21

piece_actuelle = 1
etage_actuel = 1
joueur = None
ennemi_actuel = None
pnj_actuel = None

label_image = None
label_texte = None
label_arme = None
label_armure = None
label_nom_joueur = None
label_pv = None
label_attaque = None
label_defense = None
label_or = None
label_inventaire = None
label_ennemi = None
bouton_continuer = None
bouton_attaquer = None
bouton_fuir = None
entry_nom = None
label_resultat = None

#On charge les ressoucres du jeu

DOSSIER_IMAGES = "ressources/images"
DOSSIER_IMAGES_PIECES = os.path.join(DOSSIER_IMAGES, "pieces")
DOSSIER_IMAGES_ENNEMIS = os.path.join(DOSSIER_IMAGES, "ennemis")
DOSSIER_IMAGES_PNJ = os.path.join(DOSSIER_IMAGES, "pnj")

app = QApplication(sys.argv)

fenetre = QWidget()
fenetre.setWindowTitle("Castle Explorer")

disposition = QVBoxLayout()
fenetre.setLayout(disposition)


class LabelImage(QLabel):
    # redimensionne l'image à la taille dispo sans la déformer, et la garde centrée
    def __init__(self):
        super().__init__()
        self._pixmap_original = None
        self.setAlignment(Qt.AlignCenter)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_image(self, pixmap):
        if pixmap is None or pixmap.isNull():
            self._pixmap_original = None
            super().setPixmap(QPixmap())
            return
        self._pixmap_original = pixmap
        self._rafraichir_affichage()

    def resizeEvent(self, event):
        self._rafraichir_affichage()
        super().resizeEvent(event)

    def sizeHint(self):
        return QSize(1, 1)

    def minimumSizeHint(self):
        return QSize(1, 1)

    def _rafraichir_affichage(self):
        if self._pixmap_original is None or self._pixmap_original.isNull():
            return
        pixmap_redimensionne = self._pixmap_original.scaled(
            self.width(), self.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        super().setPixmap(pixmap_redimensionne)


def couleur_piece(piece):
    if piece == 1:
        return "#3a3a5a"
    elif piece == 2:
        return "#5a2a2a"
    else:
        return "#2a4a2a"


def texte_placeholder(piece):
    if piece == 1:
        return "[Image de la pièce]"
    elif piece == 2:
        return "[Image : ennemi]"
    else:
        return "[Image : escalier + PNJ]"


def nom_fichier_ennemi(nom):
    # "Rat des égouts" -> "ennemi_rat_des_egouts.png"
    normalise = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode("ascii")
    slug = normalise.lower().replace(" ", "_").replace("'", "")
    return f"ennemi_{slug}.png"


def image_piece(etage, piece):
    chemin = os.path.join(DOSSIER_IMAGES_PIECES, f"etage{etage}_piece{piece}.jpg")
    if not os.path.exists(chemin):
        return None
    return QPixmap(chemin)


def superposer_ennemi(fond, nom_fichier_ennemi):
    chemin = os.path.join(DOSSIER_IMAGES_ENNEMIS, nom_fichier_ennemi)
    if not os.path.exists(chemin):
        return fond

    hauteur_cible = int(fond.height() * 0.8)
    ennemi = QPixmap(chemin).scaledToHeight(hauteur_cible, Qt.SmoothTransformation)
    resultat = QPixmap(fond)
    peintre = QPainter(resultat)
    x = (resultat.width() - ennemi.width()) // 2
    y = resultat.height() - ennemi.height()
    peintre.drawPixmap(x, y, ennemi)
    peintre.end()
    return resultat


def nom_fichier_pnj(nom):
    normalise = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode("ascii")
    slug = normalise.lower().replace(" ", "_").replace("'", "")
    return f"pnj_{slug}.png"


def superposer_pnj(fond, fichier_pnj):
    chemin = os.path.join(DOSSIER_IMAGES_PNJ, fichier_pnj)
    if not os.path.exists(chemin):
        return fond

    hauteur_cible = int(fond.height() * 0.8)
    pnj = QPixmap(chemin).scaledToHeight(hauteur_cible, Qt.SmoothTransformation)
    resultat = QPixmap(fond)
    peintre = QPainter(resultat)
    x = (resultat.width() - pnj.width()) // 2
    y = resultat.height() - pnj.height()
    peintre.drawPixmap(x, y, pnj)
    peintre.end()
    return resultat


def afficher_piece():
    fond = image_piece(etage_actuel, piece_actuelle)

    if fond is None:
        label_image.set_image(QPixmap())
        label_image.setText(texte_placeholder(piece_actuelle))
        label_image.setStyleSheet(f"background-color: {couleur_piece(piece_actuelle)}; color: white; border: 1px solid #888;")
    else:
        if ennemi_actuel is not None:
            fond = superposer_ennemi(fond, nom_fichier_ennemi(ennemi_actuel.nom))
        elif pnj_actuel is not None and piece_actuelle == 3:
            fond = superposer_pnj(fond, nom_fichier_pnj(pnj_actuel.nom))

        label_image.setText("")
        label_image.setStyleSheet("")
        label_image.set_image(fond)


def vider_disposition():
    while disposition.count():
        item = disposition.takeAt(0)
        widget = item.widget()
        if widget:
            widget.deleteLater()


def texte_inventaire():
    if not joueur.inventaire:
        return "(vide)"
    return "\n".join(objet.nom for objet in joueur.inventaire)


def rafraichir_inventaire():
    # Reconstruit la liste cliquable de l'inventaire à partir de joueur.inventaire
    label_inventaire.clear()
    if not joueur.inventaire:
        element = QListWidgetItem("(vide)")
        element.setFlags(Qt.NoItemFlags)
        label_inventaire.addItem(element)
        return
    for objet in joueur.inventaire:
        element = QListWidgetItem(f"{objet.nom} ({objet.type_objet} +{objet.valeur_stat})")
        element.setData(Qt.UserRole, objet)  # on range l'objet lui-même dans la ligne
        label_inventaire.addItem(element)


def utiliser_objet_inventaire(element):
    objet = element.data(Qt.UserRole)
    if objet is None:
        return

    if objet.type_objet in ("arme", "armure"):
        joueur.equiper_objet(objet)
        label_texte.setText(f"Tu équipes : {objet.nom}.")

    elif objet.type_objet == "sort":
        if ennemi_actuel is None:
            label_texte.setText(f"{objet.nom} ne peut être lancé qu'en combat.")
        else:
            joueur.utiliser_parchemin(objet, ennemi_actuel)
            label_texte.setText(f"Tu lances {objet.nom} sur {ennemi_actuel.nom} !")

            if ennemi_actuel.pv <= 0:
                gagner_combat()
                return

            message_ennemi = ennemi_actuel.attaquer(joueur)
            maj_hud()

            if joueur.pv <= 0:
                afficher_game_over()
                return

            label_texte.setText(f"Tu lances {objet.nom} !\n{message_ennemi}")

            mettre_a_jour_etat_combat()

    elif hasattr(joueur, "utiliser_objet"):
        message = joueur.utiliser_objet(objet)
        label_texte.setText(message if message else f"Tu utilises : {objet.nom}.")
    else:
        label_texte.setText(f"{objet.nom} ne peut pas encore être utilisé.")

    maj_hud()


def gagner_objet(nom):
    for objet in objets_disponibles:
        if objet.nom == nom:
            return Objet(objet.nom, objet.type_objet, objet.valeur_stat, objet.valeur_or)
    return None


def construire_ecran_accueil():
    global entry_nom, label_resultat

    vider_disposition()

    label_nom = QLabel("Quel est ton nom jeune aventurier ?")
    entry_nom = QLineEdit()
    label_resultat = QLabel("")
    bouton_valider = QPushButton("Valider")
    bouton_valider.clicked.connect(valider)

    disposition.addWidget(label_nom)
    disposition.addWidget(entry_nom)
    disposition.addWidget(label_resultat)
    disposition.addWidget(bouton_valider)


def construire_ecran_jeu():
    global label_image, label_texte, label_arme, label_armure, label_nom_joueur
    global label_pv, label_attaque, label_defense, label_or, label_inventaire, bouton_continuer
    global label_ennemi, bouton_attaquer, bouton_fuir, bouton_marchander

    vider_disposition()

    label_image = LabelImage()
    disposition.addWidget(label_image, 1)

    zone_basse = QWidget()
    zone_basse.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
    disposition_basse = QVBoxLayout()
    disposition_basse.setContentsMargins(0, 0, 0, 0)
    zone_basse.setLayout(disposition_basse)

    label_texte = QLabel(pieces[etage_actuel, piece_actuelle])
    label_texte.setWordWrap(True)
    disposition_basse.addWidget(label_texte)

    ligne_panneaux = QHBoxLayout()

    groupe_stats = QGroupBox("Statistiques")
    layout_stats = QVBoxLayout()
    label_nom_joueur = QLabel(f"Nom : {joueur.nom}")
    label_pv = QLabel(f"PV : {joueur.pv}")
    label_attaque = QLabel(f"Attaque : {joueur.attaque}")
    label_defense = QLabel(f"Défense : {joueur.defense}")
    label_or = QLabel(f"Or : {joueur.argent}")
    layout_stats.addWidget(label_nom_joueur)
    layout_stats.addWidget(label_pv)
    layout_stats.addWidget(label_attaque)
    layout_stats.addWidget(label_defense)
    layout_stats.addWidget(label_or)
    groupe_stats.setLayout(layout_stats)
    ligne_panneaux.addWidget(groupe_stats, 1)

    groupe_inventaire = QGroupBox("Inventaire")
    layout_inventaire = QVBoxLayout()
    label_inventaire = QListWidget()
    label_inventaire.setToolTip("Double-clic sur un objet pour l'équiper ou l'utiliser")
    label_inventaire.itemDoubleClicked.connect(utiliser_objet_inventaire)
    layout_inventaire.addWidget(label_inventaire)
    rafraichir_inventaire()
    groupe_inventaire.setLayout(layout_inventaire)
    ligne_panneaux.addWidget(groupe_inventaire, 1)

    groupe_combat = QGroupBox("Combat")
    layout_combat = QVBoxLayout()
    label_ennemi = QLabel("Aucun ennemi")
    bouton_attaquer = QPushButton("Attaquer")
    bouton_marchander = QPushButton("Marchander")
    bouton_fuir = QPushButton("Fuir")
    bouton_attaquer.clicked.connect(attaquer)
    bouton_fuir.clicked.connect(fuir)
    bouton_marchander.clicked.connect(marchander)
    bouton_marchander.setEnabled(False)
    layout_combat.addWidget(label_ennemi)
    layout_combat.addWidget(bouton_attaquer)
    layout_combat.addWidget(bouton_marchander)
    layout_combat.addWidget(bouton_fuir)
    groupe_combat.setLayout(layout_combat)
    ligne_panneaux.addWidget(groupe_combat, 1)

    groupe_equipement = QGroupBox("Équipement")
    layout_equipement = QVBoxLayout()
    label_arme = QLabel(f"Arme : {joueur.arme.nom if joueur.arme else 'Aucune'}")
    label_armure = QLabel(f"Armure : {joueur.armure.nom if joueur.armure else 'Aucune'}")
    layout_equipement.addWidget(label_arme)
    layout_equipement.addWidget(label_armure)
    groupe_equipement.setLayout(layout_equipement)
    ligne_panneaux.addWidget(groupe_equipement, 1)

    disposition_basse.addLayout(ligne_panneaux, 1)

    disposition.addWidget(zone_basse, 1)

    # Bouton Continuer -> Changer de pièce
    bouton_continuer = QPushButton("Continuer")
    bouton_continuer.clicked.connect(piece_suivante)
    disposition.addWidget(bouton_continuer)

    entrer_dans_piece()


def maj_hud():
    label_pv.setText(f"PV : {joueur.pv}")
    label_attaque.setText(f"Attaque : {joueur.attaque}")
    label_defense.setText(f"Défense : {joueur.defense}")
    label_or.setText(f"Or : {joueur.argent}")
    label_arme.setText(f"Arme : {joueur.arme.nom if joueur.arme else 'Aucune'}")
    label_armure.setText(f"Armure : {joueur.armure.nom if joueur.armure else 'Aucune'}")
    rafraichir_inventaire()


def entrer_dans_piece():
    global ennemi_actuel, pnj_actuel

    if etage_actuel == ETAGE_FINAL and piece_actuelle == 1:
        # Combat final : toujours le dernier ennemi de la liste (le boss)
        modele = ennemis_disponibles[-1]
        ennemi_actuel = Ennemi(modele.pv, modele.argent, modele.nom, modele.attaque, modele.defense, "Vivant", modele.or_butin, modele.objet_butin)
        pnj_actuel = None
    elif piece_actuelle == 2:
        if ennemi_actuel is None:
            ennemi_actuel = tirer_ennemi(etage_actuel, ennemis_disponibles)
        pnj_actuel = None
    elif piece_actuelle == 3:
        ennemi_actuel = None
        pnj_actuel = tirer_pnj(pnj_disponibles)
        label_texte.setText(f"{pnj_actuel.nom} est là. Clique sur Marchander pour voir ses offres.")
    else:
        ennemi_actuel = None
        pnj_actuel = None

    afficher_piece()
    mettre_a_jour_etat_combat()


def mettre_a_jour_etat_combat():
    en_combat = ennemi_actuel is not None
    bouton_attaquer.setEnabled(en_combat)
    combat_final = etage_actuel == ETAGE_FINAL and piece_actuelle == 1
    bouton_fuir.setEnabled(en_combat and not combat_final)  # pas de fuite face au boss
    bouton_marchander.setEnabled(not en_combat and piece_actuelle == 3)
    bouton_continuer.setEnabled(not en_combat)

    if en_combat:
        label_ennemi.setText(f"{ennemi_actuel.nom}\nPV : {ennemi_actuel.pv}")
    else:
        label_ennemi.setText("Aucun ennemi")


def marchander():
    if pnj_actuel is None:
        return

    type_marchand = pnj_actuel.type_pnj

    # Choix : Acheter ou Vendre
    choix, ok = QInputDialog.getItem(fenetre, "Marchander", f"{pnj_actuel.nom} — que veux-tu faire ?", ["Acheter", "Vendre"], 0, False)
    if not ok:
        return

    if choix == "Acheter":
        # Filtrer les objets du type du marchand
        objets_en_vente = [obj for obj in objets_disponibles if obj.type_objet == type_marchand]
        if not objets_en_vente:
            label_texte.setText(f"{pnj_actuel.nom} n'a rien à vendre.")
            return

        noms = [f"{obj.nom} — {obj.valeur_or} or (+{obj.valeur_stat})" for obj in objets_en_vente]
        choix_obj, ok = QInputDialog.getItem(fenetre, "Acheter", f"Ton or : {joueur.argent}. Choisis un objet :", noms, 0, False)
        if not ok:
            return

        index = noms.index(choix_obj)
        modele = objets_en_vente[index]

        if joueur.argent < modele.valeur_or:
            label_texte.setText(f"Tu n'as pas assez d'or pour {modele.nom} ({modele.valeur_or} or). Tu as {joueur.argent} or.")
            return

        objet_achete = gagner_objet(modele.nom)
        if objet_achete is None:
            return
        joueur.perdre_argent(modele.valeur_or)
        joueur.ramasser_objet(objet_achete)
        label_texte.setText(f"Tu achètes {modele.nom} pour {modele.valeur_or} or.")
        maj_hud()

    elif choix == "Vendre":
        # Objets du type du marchand : ceux de l'inventaire + celui qui est équipé
        objets_vendables = [obj for obj in joueur.inventaire if obj.type_objet == type_marchand]
        for equipe in (joueur.arme, joueur.armure):
            if equipe is not None and equipe.type_objet == type_marchand:
                objets_vendables.append(equipe)

        noms_types = {"arme": "des armes", "armure": "des armures", "consommable": "des potions", "sort": "des sorts"}
        if not objets_vendables:
            label_texte.setText(f"{pnj_actuel.nom} n'achète que {noms_types.get(type_marchand, type_marchand)}, et tu n'en as pas.")
            return

        noms = []
        for i, obj in enumerate(objets_vendables):
            etiquette = " (équipé)" if obj is joueur.arme or obj is joueur.armure else ""
            noms.append(f"{i + 1}. {obj.nom}{etiquette} — {obj.valeur_or // 2} or")
        choix_obj, ok = QInputDialog.getItem(fenetre, "Vendre", "Choisis un objet à vendre (moitié du prix) :", noms, 0, False)
        if not ok:
            return

        index = noms.index(choix_obj)
        objet_vendu = objets_vendables[index]
        prix_vente = objet_vendu.valeur_or // 2

        if objet_vendu is joueur.arme or objet_vendu is joueur.armure:
            joueur.deequiper_objet(objet_vendu)  # retire le bonus et libère l'emplacement
        else:
            joueur.tomber_objet(objet_vendu)
        joueur.gagner_argent(prix_vente)
        label_texte.setText(f"Tu vends {objet_vendu.nom} pour {prix_vente} or.")
        maj_hud()


def gagner_combat():
    global ennemi_actuel

    joueur.argent += ennemi_actuel.or_butin
    message = f"Tu as vaincu {ennemi_actuel.nom} ! Tu gagnes {ennemi_actuel.or_butin} pièces d'or."

    if ennemi_actuel.objet_butin != "Rien":
        objet_gagne = gagner_objet(ennemi_actuel.objet_butin)
        if objet_gagne is not None:
            joueur.ramasser_objet(objet_gagne)
            message += f" Tu récupères : {objet_gagne.nom}."

    ennemi_actuel = None
    label_texte.setText(message)
    maj_hud()
    afficher_piece()
    mettre_a_jour_etat_combat()


def attaquer():
    if ennemi_actuel is None:
        return

    message_joueur = joueur.attaquer(ennemi_actuel)

    if ennemi_actuel.pv <= 0:
        gagner_combat()
        return

    message_ennemi = ennemi_actuel.attaquer(joueur)
    maj_hud()

    if joueur.pv <= 0:
        afficher_game_over()
        return

    label_texte.setText(f"{message_joueur}\n{message_ennemi}")
    mettre_a_jour_etat_combat()


def fuir():
    global ennemi_actuel

    if random.random() < 0.5:
        label_texte.setText(f"Tu fuis {ennemi_actuel.nom} avec succès.")
        ennemi_actuel = None
        afficher_piece()
        mettre_a_jour_etat_combat()
    else:
        message = ennemi_actuel.attaquer(joueur)
        maj_hud()

        if joueur.pv <= 0:
            afficher_game_over()
            return

        label_texte.setText(f"Ta fuite échoue ! {message}")
        mettre_a_jour_etat_combat()


def afficher_game_over():
    vider_disposition()

    label_game_over = QLabel("Game Over")
    label_game_over.setAlignment(Qt.AlignCenter)
    label_game_over.setStyleSheet("font-size: 48px; font-weight: bold; color: #b03030;")

    bouton_rejouer = QPushButton("Recommencer")
    bouton_rejouer.clicked.connect(recommencer)

    disposition.addWidget(label_game_over, 1)
    disposition.addWidget(bouton_rejouer)


def afficher_victoire():
    vider_disposition()

    label_victoire = QLabel("Victoire !")
    label_victoire.setAlignment(Qt.AlignCenter)
    label_victoire.setStyleSheet("font-size: 48px; font-weight: bold; color: #d4af37;")

    texte_fin = pieces.get((ETAGE_FINAL, 2), "Bravo, tu as fini le jeu !")
    label_message = QLabel(f"{texte_fin}\n\n{joueur.nom} a vaincu le maître du donjon.")
    label_message.setAlignment(Qt.AlignCenter)
    label_message.setWordWrap(True)
    label_message.setStyleSheet("font-size: 20px;")

    arme = joueur.arme.nom if joueur.arme else "Aucune"
    armure = joueur.armure.nom if joueur.armure else "Aucune"
    label_bilan = QLabel(
        f"PV restants : {joueur.pv}   |   Attaque : {joueur.attaque}   |   Défense : {joueur.defense}   |   Or : {joueur.argent}\n"
        f"Arme : {arme}   |   Armure : {armure}"
    )
    label_bilan.setAlignment(Qt.AlignCenter)

    bouton_rejouer = QPushButton("Rejouer")
    bouton_rejouer.clicked.connect(recommencer)
    bouton_quitter = QPushButton("Quitter")
    bouton_quitter.clicked.connect(fenetre.close)

    disposition.addWidget(label_victoire, 1)
    disposition.addWidget(label_message)
    disposition.addWidget(label_bilan, 1)
    disposition.addWidget(bouton_rejouer)
    disposition.addWidget(bouton_quitter)


def recommencer():
    global piece_actuelle, etage_actuel, joueur, ennemi_actuel, pnj_actuel

    piece_actuelle = 1
    etage_actuel = 1
    joueur = None
    ennemi_actuel = None
    pnj_actuel = None

    construire_ecran_accueil()


def valider(): # Ecran de creation du personnage on verifie que le nom soit valide 
    global joueur
    nom_saisi = entry_nom.text()

    if verifier_nom(nom_saisi):
        joueur = Personnage(100, 0, nom_saisi, 10, 10, "Vivant")
        construire_ecran_jeu()
    else:
        label_resultat.setText("Nom invalide (lettres uniquement, 10 caractères max), réessaie.")


def piece_suivante(): # Gestion du changement de piece
    global piece_actuelle, etage_actuel

    piece_actuelle += 1
    if piece_actuelle == 4:
        piece_actuelle = 1
        etage_actuel += 1

    # Après le boss (étage 21, pièce 1) : fin du jeu
    if etage_actuel == ETAGE_FINAL and piece_actuelle == 2:
        afficher_victoire()
        return

    label_texte.setText(pieces[etage_actuel, piece_actuelle])
    maj_hud()
    entrer_dans_piece()


# On configure la touche echap pour quitter le jeu
raccourci_quitter = QShortcut(QKeySequence("Escape"), fenetre)
raccourci_quitter.activated.connect(fenetre.close)

construire_ecran_accueil()

fenetre.showFullScreen()
sys.exit(app.exec())
