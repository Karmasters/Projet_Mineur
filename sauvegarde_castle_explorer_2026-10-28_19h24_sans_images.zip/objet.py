class Personnage :

    def __init__(self, pv, argent, nom, attaque, defense, etat, arme=None, armure=None, inventaire=None):
        self.pv = pv 
        self.argent = argent
        self.nom = nom
        self.attaque = attaque
        self.defense = defense
        self.etat = etat
        self.arme = arme
        self.armure = armure

        if inventaire is None:
            self.inventaire = []
        else:
            self.inventaire = inventaire

    def perd_de_la_vie(self, degat): #Verifie si le personnage perd de la vie
        pv = self.pv - degat
        self.pv = pv

    def gagne_de_la_vie(self,vie_recu):
        pv = self.pv + vie_recu
        self.pv = pv

    def attaquer(self, Personnage): #Permet a un personnage d'en attaquer un autre et retourne le résultat 
        degat = self.attaque - Personnage.defense
        if(degat <= 0):
            return f"L'attaque du combattant {self.nom} n'est pas éfficace"
        else:
            pv_final = Personnage.pv - degat
            Personnage.pv = pv_final
            return f"Le combattant {Personnage.nom} perd {degat} pv"

    def ramasser_objet(self, Objet): #Le personnage gagne l'objet vers son inventaire 
        self.inventaire.append(Objet)

    def tomber_objet(self, Objet):  # Le personnage perd l'objet de son inventaire 
        self.inventaire.remove(Objet)

    def equiper_objet(self, Objet): #Le personnage equipe l'objet
        type_cible = Objet.type_objet

        if type_cible == "armure": #Pour s'équiper d'une armure
            if self.armure != None: #Si le joueur a une armure
                self.ramasser_objet(self.armure)
                self.deequiper_objet(self.armure)
                self.tomber_objet(Objet)
                self.armure = Objet
                self.defense += Objet.valeur_stat
            else: #Si le joueur n'a pas d'armure 
                self.tomber_objet(Objet)
                self.armure = Objet
                self.defense += Objet.valeur_stat

        elif type_cible == "arme": #Pour s'équiper d'une arme
            if self.arme != None: #Si le joueur a une arme
                self.ramasser_objet(self.arme)
                self.deequiper_objet(self.arme)
                self.tomber_objet(Objet)
                self.arme = Objet
                self.attaque += Objet.valeur_stat
            
            else: #Si le joueur n'a pas d'arme
                self.tomber_objet(Objet)
                self.arme = Objet
                self.attaque += Objet.valeur_stat

        else :
            return "c'est cassé"

    def deequiper_objet(self, Objet): # Le personnage se déequippe de l'objet
        type_cible = Objet.type_objet
        if type_cible == "arme":
            self.attaque -= Objet.valeur_stat
            self.arme = None
        elif type_cible == "armure":
            self.defense -= Objet.valeur_stat
            self.armure = None
        else:
            return "c'est cassé"

    def gagner_argent(self, argent_recu): # Le personnage gagne de l'argent
        self.argent += argent_recu

    def perdre_argent(self, argent_perdu): # Le personnage perd de l'argent
        self.argent -= argent_perdu

    def utiliser_objet(self, Objet):
        if Objet.type_objet == "consommable":
            self.utiliser_potion(Objet)
            return f"Tu utilises {Objet.nom} !"
        elif Objet.type_objet == "sort":
            return f"{Objet.nom} ne peut être lancé qu'en combat."
        else:
            return f"{Objet.nom} ne peut pas être utilisé."

    def utiliser_potion(self, Objet):

        if Objet.nom == "Potion de vie":
            self.pv += Objet.valeur_stat
            self.tomber_objet(Objet)

        elif Objet.nom == "Potion de puissance":
                    self.attaque += Objet.valeur_stat
                    self.tomber_objet(Objet)

        elif Objet.nom == "Potion de forteresse":
                    self.defense += Objet.valeur_stat
                    self.tomber_objet(Objet)

    def utiliser_parchemin(self, Objet, Ennemi):

        if Objet.nom == "Boule de feu":
            Ennemi.pv -= Objet.valeur_stat
            self.tomber_objet(Objet)

        elif Objet.nom == "Tempete electrique":
            Ennemi.pv -= Objet.valeur_stat
            Ennemi.defense -= Objet.valeur_stat 
            self.tomber_objet(Objet)

        elif Objet.nom == "Drain de vie":
            Ennemi.pv -= Objet.valeur_stat
            self.pv += Objet.valeur_stat 
            self.tomber_objet(Objet)
            
class Ennemi(Personnage) : #Personnage ennemi, possede un butin et de l'or
    def __init__(self, pv, argent, nom, attaque, defense, etat, or_butin, objet_butin):
        super().__init__(pv, argent, nom, attaque, defense, etat)
        self.or_butin = or_butin
        self.objet_butin = objet_butin

class PNJ(Personnage) : #Personnage neutre (marchand) possede or ou objet pour le joueur 
    def __init__(self, pv, argent, nom, attaque, defense, etat, or_transaction, objet_transaction, type_pnj="marchand"):
        super().__init__(pv, argent, nom, attaque, defense, etat)
        self.or_transaction = or_transaction
        self.objet_transaction = objet_transaction
        self.type_pnj = type_pnj

class Objet(): # Un objet peut être équipé par un joueur ou stocké dans son inventaire. Il peut être vendu. Il donnera selon son type des valeurs de défense ou d'attaque.
    def __init__(self, nom, type_objet, valeur_stat, valeur_or):
        self.nom = nom
        self.type_objet = type_objet
        self.valeur_stat = valeur_stat
        self.valeur_or = valeur_or

