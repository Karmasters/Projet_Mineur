import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame

app = QApplication(sys.argv)          # On crée le moteur de l'interface graphique

fenetre = QMainWindow()               # On crée la fenetre principale
fenetre.setWindowTitle("Castle Explorer")
fenetre.resize(800, 600)              # Paramétrage de la dimension de la fenêtre


############################# Construction de la structure #############################

central = QWidget()
ligne_principale = QHBoxLayout(central)     # la grande ligne, posée sur le support

# ----- Colonne gauche : PV + stats du joueur -----
col_gauche = QVBoxLayout()

zone_stats = QLabel("Stats")
zone_stats.setFrameShape(QFrame.Box)    # Un cadre pour voir la zone
col_gauche.addWidget(zone_stats)

zone_equipement = QLabel("Equipement")
zone_equipement.setFrameShape(QFrame.Box)    # Un cadre pour voir la zone
col_gauche.addWidget(zone_equipement)

# ----- Colonne centrale  -----
col_central = QVBoxLayout()

zone_etage_piece = QLabel("Etage : - Pièce :")
zone_etage_piece.setFrameShape(QFrame.Box)
col_central.addWidget(zone_etage_piece)


zone_image = QLabel("Image de la pièce")
zone_image.setFrameShape(QFrame.Box)
col_central.addWidget(zone_image, 4)          

zone_texte = QLabel("Texte du jeu")
zone_texte.setFrameShape(QFrame.Box)
col_central.addWidget(zone_texte, 2)          


ligne_boutons = QHBoxLayout()               # la ligne de boutons d'actions
bouton_avancer = QPushButton("Avancer") 
bouton_attaquer = QPushButton("Attaquer")
bouton_fuir = QPushButton("Fuir")   
bouton_marchander = QPushButton("Marchander")        
ligne_boutons.addWidget(bouton_avancer)
ligne_boutons.addWidget(bouton_attaquer)
ligne_boutons.addWidget(bouton_fuir)
ligne_boutons.addWidget(bouton_marchander)
col_central.addLayout(ligne_boutons)        

# ----- Colonne droite : inventaire -----
col_droite = QVBoxLayout()
zone_inventaire = QLabel("Inventaire")
zone_inventaire.setFrameShape(QFrame.Box)
col_droite.addWidget(zone_inventaire)

# ----- Assemblage des 3 colonnes -----
ligne_principale.addLayout(col_gauche, 1)   # étirement 1

ligne_principale.addLayout(col_central, 3)  # étirement 3 -> trois fois plus large

ligne_principale.addLayout(col_droite, 1)   # étirement 1

fenetre.setCentralWidget(central)

############################# Lancement du jeu #############################
fenetre.show()                        # On affiche la Fenetre
code = app.exec()                     # lance la boucle d'événements (bloque jusqu'à la fermeture)
print("Fin du jeu")
sys.exit(code)                        # quitte proprement avec le code renvoyé